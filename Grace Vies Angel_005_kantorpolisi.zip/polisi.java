import java.util.ArrayList;
import java.util.Scanner;

public class polisi {

    // ====== MODEL SEDERHANA ======
    static class Polisi { String nrp,nama,pangkat,status;
        Polisi(String n,String a,String p,String s){ nrp=n; nama=a; pangkat=p; status=s; } }
    static class Jadwal { String id,tanggal,area,nrp,status;
        Jadwal(String i,String t,String r,String n,String s){ id=i; tanggal=t; area=r; nrp=n; status=s; } }
    static class Kasus { String id,judul,status,penyidikNRP;
        Kasus(String i,String j,String s,String n){ id=i; judul=j; status=s; penyidikNRP=n; } }

    // ====== DATA ======
    static ArrayList<Polisi> polisi = new ArrayList<>();
    static ArrayList<Jadwal> jadwal = new ArrayList<>();
    static ArrayList<Kasus>  kasus  = new ArrayList<>();
    static Scanner in = new Scanner(System.in);
    static int seqJ=1, seqK=1;                // J-1, J-2 ... ; K-1, K-2 ...
    static final int WBOX = 62;               // lebar kotak

    // ====== MAIN ======
    public static void main(String[] args) {
        seed();
        while (true) {
            System.out.println("**************************************************************");
            System.out.println("*                       KANTOR POLISI                        *");
            System.out.println("**************************************************************");
            System.out.println("**************************************************************");
            System.out.println("*          SELAMAT DATANG DI SISTEM KANTOR POLISI            *");
            System.out.println("**************************************************************");
            boxMenu("MENU UTAMA", new String[]{
                "1. INFORMASI POLISI",
                "2. JADWAL PATROLI",
                "3. KASUS PENYELIDIKAN",
                "4. KELUAR"
            }, WBOX);
            System.out.print("\nPilih: ");
            switch (in.nextLine()) {
                case "1": menuPolisi(); break;
                case "2": menuJadwal(); break;
                case "3": menuKasus();  break;
                case "4": System.out.println("Selesai."); return;
                default : System.out.println("Pilihan salah.\n");
            }
        }
    }

    // ====== INFORMASI POLISI ======
    static void menuPolisi(){
        boolean jalan=true;
        while (jalan){
            boxMenu("FITUR INFORMASI POLISI", new String[]{
                "1. Tambah data polisi",
                "2. Lihat Data",
                "3. Detail Ringkasan (by NRP)",
                "4. Ubah Data",
                "5. Hapus Data Polisi",
                "6. Kembali"
            }, WBOX);
            System.out.print("\nPilih: ");
            switch (in.nextLine()){
                case "1": tambahPolisi(); break;
                case "2": lihatPolisi();  break;
                case "3": detailPolisi(); break;
                case "4": ubahPolisi();   break;
                case "5": hapusPolisi();  break;
                case "6": jalan=false;    break;
                default : System.out.println("Pilihan salah.\n");
            }
        }
    }
    static void tambahPolisi(){
        System.out.println("\nTAMBAH DATA POLISI");
        System.out.print("NRP (3 angka & unik): "); String nrp = in.nextLine();
        if (!tigaAngka(nrp) || findPolisi(nrp)!=-1){ System.out.println("NRP tidak valid/duplikat.\n"); return; }
        System.out.print("Nama: "); String nama = in.nextLine();
        System.out.print("Pangkat : "); String pang = in.nextLine();
        String st; do { System.out.print("Status [Aktif/Cuti]: "); st = in.nextLine(); }
        while (!st.equalsIgnoreCase("Aktif") && !st.equalsIgnoreCase("Cuti")); // do-while
        polisi.add(new Polisi(nrp, nama, pang, kapital(st)));
    }
    static void lihatPolisi(){
        header("DAFTAR POLISI", 70);
        // kolom: NRP, Nama, Pangkat, Status
        int[] W = {6, 24, 16, 12};
        printHead(new String[]{"NRP","Nama","Pangkat","Status"}, W);
        for (int i=0;i<polisi.size();i++){
            Polisi p=polisi.get(i);
            printRow(new String[]{ p.nrp, p.nama, p.pangkat, p.status }, W);
        }
        garis(totalLen(W));
        System.out.println();
    }
    static void detailPolisi(){
        System.out.print("\nMasukkan NRP: "); String nrp = in.nextLine();
        int idx = findPolisi(nrp);
        if (idx==-1){ System.out.println("NRP tidak ditemukan.\n"); return; }
        Polisi p = polisi.get(idx);
        garis(60);
        System.out.println("NRP    : "+p.nrp);
        System.out.println("Nama   : "+p.nama);
        System.out.println("Pangkat: "+p.pangkat);
        System.out.println("Status : "+p.status);
        garis(60);
    }
    static void ubahPolisi(){
        System.out.print("\nMasukkan NRP: "); String nrp = in.nextLine();
        int i = findPolisi(nrp);
        if (i==-1){ System.out.println("NRP tidak ditemukan.\n"); return; }
        Polisi p = polisi.get(i);
        System.out.print("Nama ("+p.nama+"): "); String nama = in.nextLine();
        System.out.print("Pangkat : ");          String pang = in.nextLine();
        System.out.print("Status [Aktif/Cuti]: "); String st = in.nextLine();
        if (!nama.equals("")) p.nama = nama;
        if (!pang.equals("")) p.pangkat = pang;
        if (st.equalsIgnoreCase("Aktif")||st.equalsIgnoreCase("Cuti")) p.status = kapital(st);
    }
    static void hapusPolisi(){
        System.out.print("\nMasukkan NRP: "); String nrp = in.nextLine();
        int i = findPolisi(nrp);
        if (i==-1){ System.out.println("NRP tidak ditemukan.\n"); return; }
        polisi.remove(i);
    }

    // ====== JADWAL PATROLI ======
    static void menuJadwal(){
        boolean jalan=true;
        while (jalan){
            boxMenu("JADWAL PATROLI", new String[]{
                "1. Buat Jadwal",
                "2. Lihat Jadwal",
                "3. Ubah Jadwal (Tanggal/Area) & Tandai Telah Selesai",
                "4. Filter Area/Status",
                "5. Hapus Jadwal",
                "6. Kembali"
            }, WBOX);
            System.out.print("\nPilih: ");
            switch (in.nextLine()){
                case "1": buatJadwal(); break;
                case "2": lihatJadwal(jadwal); break;
                case "3": ubahJadwal(); break;
                case "4": filterJadwal(); break;
                case "5": hapusJadwal(); break;
                case "6": jalan=false; break;
                default : System.out.println("Pilihan salah.\n");
            }
        }
    }
    static void buatJadwal(){
        System.out.println("\nBUAT JADWAL");
        String id = "J-"+(seqJ++);                       // J-1, J-2, ...
        System.out.print("Tanggal (dd-MM-yyyy): "); String t = in.nextLine();
        System.out.print("Area: "); String a = in.nextLine();
        System.out.print("NRP petugas (3 angka): "); String nrp = in.nextLine();
        if (findPolisi(nrp)==-1){ System.out.println("NRP tidak ada.\n"); return; }
        jadwal.add(new Jadwal(id, t, a, nrp, "Dijadwalkan"));
    }
    static void lihatJadwal(ArrayList<Jadwal> list){
        header("DAFTAR JADWAL", 96);
        // kolom: ID, Tanggal, Area, Nama Polisi, Status
        int[] W = {6, 12, 28, 30, 14};
        printHead(new String[]{"ID","Tanggal","Area","Nama Polisi","Status"}, W);

        for (int i=0;i<list.size();i++){
            Jadwal j=list.get(i);
            int idx = findPolisi(j.nrp);
            String nm = (idx==-1)? "(NRP?)" : polisi.get(idx).nama+" ("+polisi.get(idx).pangkat+")";
            printRow(new String[]{ j.id, j.tanggal, j.area, nm, j.status }, W);
        }
        garis(totalLen(W));
        System.out.println();
    }
    static void ubahJadwal(){
        System.out.print("\nID Jadwal: "); String id = in.nextLine();
        int i = findJadwal(id);
        if (i==-1){ System.out.println("ID tidak ditemukan.\n"); return; }
        Jadwal j = jadwal.get(i);
        System.out.println("1) Ubah Tanggal  2) Ubah Area  3) Tandai Telah Selesai  4) Batal");
        System.out.print("Pilih: "); String p = in.nextLine();
        if (p.equals("1")) { System.out.print("Tanggal baru: "); j.tanggal = in.nextLine(); }
        else if (p.equals("2")) { System.out.print("Area baru: "); j.area    = in.nextLine(); }
        else if (p.equals("3")) { j.status = "Telah Selesai"; }
    }
    static void filterJadwal(){
        System.out.println("\nFILTER JADWAL");
        System.out.println("1) Area   2) Status   3) Area + Status");
        System.out.print("Pilih: "); String p = in.nextLine();
        ArrayList<Jadwal> hasil = new ArrayList<>();
        if (p.equals("1")){
            System.out.print("Area: "); String a = in.nextLine();
            for (int i=0;i<jadwal.size();i++) if (jadwal.get(i).area.equalsIgnoreCase(a)) hasil.add(jadwal.get(i));
        } else if (p.equals("2")){
            System.out.print("Status (Dijadwalkan/Telah Selesai): "); String s = in.nextLine();
            for (int i=0;i<jadwal.size();i++) if (jadwal.get(i).status.equalsIgnoreCase(s)) hasil.add(jadwal.get(i));
        } else if (p.equals("3")){
            System.out.print("Area: "); String a = in.nextLine();
            System.out.print("Status (Dijadwalkan/Telah Selesai): "); String s = in.nextLine();
            for (int i=0;i<jadwal.size();i++)
                if (jadwal.get(i).area.equalsIgnoreCase(a) && jadwal.get(i).status.equalsIgnoreCase(s)) hasil.add(jadwal.get(i));
        } else { System.out.println("Pilihan salah.\n"); return; }
        lihatJadwal(hasil);
    }
    static void hapusJadwal(){
        System.out.print("\nID Jadwal: "); String id = in.nextLine();
        int i = findJadwal(id);
        if (i==-1){ System.out.println("ID tidak ditemukan.\n"); return; }
        jadwal.remove(i);
    }

    // ====== KASUS ======
    static void menuKasus(){
        boolean jalan=true;
        while (jalan){
            boxMenu("KASUS PENYELIDIKAN", new String[]{
                "1. Tambah Kasus",
                "2. Lihat Kasus (Filter Status)",
                "3. Ubah Status (Baru/Proses/Ditutup)",
                "4. Hapus Kasus",
                "5. Kembali"
            }, WBOX);
            System.out.print("\nPilih: ");
            switch (in.nextLine()){
                case "1": tambahKasus();  break;
                case "2": lihatKasus();   break;
                case "3": ubahStatus();   break;
                case "4": hapusKasus();   break;
                case "5": jalan=false;    break;
                default : System.out.println("Pilihan salah.\n");
            }
        }
    }
    static void tambahKasus(){
        System.out.println("\nTAMBAH KASUS");
        String id = "K-"+(seqK++);                    // K-1, K-2, ...
        System.out.print("Judul: "); String j = in.nextLine();
        System.out.print("Penyidik NRP (3 angka): "); String n = in.nextLine();
        if (findPolisi(n)==-1){ System.out.println("NRP tidak ada.\n"); return; }
        kasus.add(new Kasus(id, j, "Baru", n));
    }
    static void lihatKasus(){
        System.out.println("\nLIHAT KASUS");
        System.out.println("1) Semua  2) Baru  3) Proses  4) Ditutup");
        System.out.print("Pilih: "); String p = in.nextLine();
        if (p.equals("1")){
            tampilKasus("SEMUA", kasus);
            tampilKasus("BARU", filterKasus("Baru"));
            tampilKasus("PROSES", filterKasus("Proses"));
            tampilKasus("DITUTUP", filterKasus("Ditutup"));
        } else if (p.equals("2")) tampilKasus("BARU",    filterKasus("Baru"));
        else if (p.equals("3"))   tampilKasus("PROSES",  filterKasus("Proses"));
        else if (p.equals("4"))   tampilKasus("DITUTUP", filterKasus("Ditutup"));
        else System.out.println("Pilihan salah.\n");
    }
    static void ubahStatus(){
        System.out.print("\nID Kasus: "); String id = in.nextLine();
        int i = findKasus(id);
        if (i==-1){ System.out.println("ID tidak ditemukan.\n"); return; }
        System.out.println("1) Baru  2) Proses  3) Ditutup");
        System.out.print("Pilih: "); String p = in.nextLine();
        if (p.equals("1")) kasus.get(i).status = "Baru";
        else if (p.equals("2")) kasus.get(i).status = "Proses";
        else if (p.equals("3")) kasus.get(i).status = "Ditutup";
    }
    static void hapusKasus(){
        System.out.print("\nID Kasus: "); String id = in.nextLine();
        int i = findKasus(id);
        if (i==-1){ System.out.println("ID tidak ditemukan.\n"); return; }
        kasus.remove(i);
    }
    static void tampilKasus(String judul, ArrayList<Kasus> list){
        header("["+judul+"]", 80);
        int[] W = {6, 42, 12, 10}; // ID, Judul, Status, Penyidik
        printHead(new String[]{"ID","Judul","Status","Penyidik"}, W);
        for (int i=0;i<list.size();i++){
            Kasus k=list.get(i);
            printRow(new String[]{ k.id, k.judul, k.status, k.penyidikNRP }, W);
        }
        garis(totalLen(W));
        System.out.println();
    }

    // ====== FIND / FILTER / UTIL ======
    static int findPolisi(String nrp){ for (int i=0;i<polisi.size();i++) if (polisi.get(i).nrp.equals(nrp)) return i; return -1; }
    static int findJadwal(String id){ for (int i=0;i<jadwal.size();i++) if (jadwal.get(i).id.equalsIgnoreCase(id)) return i; return -1; }
    static int findKasus (String id){ for (int i=0;i<kasus.size();i++)  if (kasus.get(i).id.equalsIgnoreCase(id))  return i; return -1; }
    static ArrayList<Kasus> filterKasus(String st){ ArrayList<Kasus> h=new ArrayList<>(); for(int i=0;i<kasus.size();i++) if(kasus.get(i).status.equalsIgnoreCase(st)) h.add(kasus.get(i)); return h; }
    static boolean tigaAngka(String s){ return s!=null && s.length()==3 && s.charAt(0)>='0'&&s.charAt(0)<='9' && s.charAt(1)>='0'&&s.charAt(1)<='9' && s.charAt(2)>='0'&&s.charAt(2)<='9'; }
    static String kapital(String s){ return s.substring(0,1).toUpperCase()+s.substring(1).toLowerCase(); }

    // ====== KOTAK BERGAYA (mirip foto) ======
    static void boxMenu(String title, String[] lines, int w){
        String topBot = pola("=.", w);
        String dinding = "|" + spasi(w-2) + "|";
        String judul   = "|" + tengah(title, w-2) + "|";
        String pemisah = "|" + pola("-.", w-2) + "|";
        System.out.println(topBot);
        System.out.println(dinding);
        System.out.println(judul);
        System.out.println(pemisah);
        for (String line : lines) {
            System.out.println("| " + padRight(line, w-3) + "|");
        }
        System.out.println(topBot);
    }
    static void header(String title, int w){
        String topBot = pola("=.", w);
        System.out.println(topBot);
        System.out.println(tengah(title, w));
        System.out.println(topBot);
    }
    static String pola(String p, int n){ String s=""; for(int i=0;i<n;i++) s+=p.charAt(i%p.length()); return s; }
    static String spasi(int n){ String s=""; for(int i=0;i<n;i++) s+=" "; return s; }
    static String tengah(String s, int w){
        if (s.length()>=w) return s.substring(0,w);
        int kiri=(w-s.length())/2, kanan=w-s.length()-kiri;
        return spasi(kiri)+s+spasi(kanan);
    }
    static String padRight(String s, int w){
        if (s.length()>=w) return s.substring(0,w);
        return s + spasi(w - s.length());
    }
    static void garis(int n){ for(int i=0;i<n;i++) System.out.print("-"); System.out.println(); }

    // ====== HELPER TABEL RAPI ======
    static String pad(String s, int w){
        if (s == null) s = "";
        if (s.length() >= w) return s.substring(0, w);
        StringBuilder b = new StringBuilder(s);
        while (b.length() < w) b.append(' ');
        return b.toString();
    }
    static void printRow(String[] cols, int[] w){
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<w.length;i++){
            sb.append(pad(cols[i], w[i]));
            if (i < w.length-1) sb.append("  "); // 2 spasi antar kolom
        }
        System.out.println(sb.toString());
    }
    static int totalLen(int[] w){
        int sum=0; for (int i=0;i<w.length;i++) sum+=w[i];
        return sum + 2*(w.length-1);
    }
    static void printHead(String[] labels, int[] w){
        garis(totalLen(w));
        printRow(labels, w);
        garis(totalLen(w));
    }

    // ====== SEED (NRP 3 digit, ID J-/K-) ======
    static void seed(){
        // Polisi
        polisi.add(new Polisi("101","Andi Saputra","Bripda","Aktif"));
        polisi.add(new Polisi("102","Budi Hartono","Briptu","Cuti"));
        polisi.add(new Polisi("103","Citra Lestari","Bripda","Aktif"));
        polisi.add(new Polisi("104","Doni Pratama","Brigpol","Aktif"));
        polisi.add(new Polisi("105","Eka Purnama","Bripka","Aktif"));
        polisi.add(new Polisi("106","Fajar Nugraha","Aipda","Cuti"));
        polisi.add(new Polisi("107","Gilang Saputra","Ipda","Aktif"));
        polisi.add(new Polisi("108","Hana Pertiwi","Iptu","Aktif"));
        polisi.add(new Polisi("109","Indra Kurniawan","AKP","Aktif"));
        polisi.add(new Polisi("110","Joko Susilo","Kompol","Aktif"));
        polisi.add(new Polisi("111","Karin Putri","AKBP","Aktif"));
        polisi.add(new Polisi("112","Leonardo","Briptu","Aktif"));
        polisi.add(new Polisi("113","Maya Sari","Bripda","Aktif"));
        polisi.add(new Polisi("114","Naufal Rizqi","Briptu","Aktif"));
        polisi.add(new Polisi("115","Oni Prakoso","Bripka","Cuti"));

        // Jadwal (campur area & status)
        jadwal.add(new Jadwal("J-"+(seqJ++),"09-09-2025","Pasar Raya","101","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"10-09-2025","Jl. Sudirman","103","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"11-09-2025","Jl. Sudirman","109","Telah Selesai"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"12-09-2025","Pasar Raya","107","Telah Selesai"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"13-09-2025","Pasar Pagi","108","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"14-09-2025","Pasar Pagi","111","Telah Selesai"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"17-09-2025","Pelabuhan Samarinda","104","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"18-09-2025","Pelabuhan Samarinda","105","Telah Selesai"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"25-09-2025","Perumahan Bukit","111","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"26-09-2025","Perumahan Bukit","115","Telah Selesai"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"27-09-2025","Jl. Ahmad Yani","101","Dijadwalkan"));
        jadwal.add(new Jadwal("J-"+(seqJ++),"28-09-2025","Jl. P. Antasari","108","Telah Selesai"));

        // Kasus (semua status)
        kasus.add(new Kasus("K-"+(seqK++),"Pencurian Motor di Pasar Raya","Baru","101"));
        kasus.add(new Kasus("K-"+(seqK++),"Penipuan Online","Proses","109"));
        kasus.add(new Kasus("K-"+(seqK++),"Penganiayaan Ringan","Ditutup","107"));
        kasus.add(new Kasus("K-"+(seqK++),"Perjudian Ilegal","Baru","113"));
        kasus.add(new Kasus("K-"+(seqK++),"Narkoba - Pengedar Kecil","Proses","111"));
        kasus.add(new Kasus("K-"+(seqK++),"Laka Lantas Jl. Sudirman","Ditutup","103"));
        kasus.add(new Kasus("K-"+(seqK++),"Pencurian Rumah Kosong","Baru","114"));
        kasus.add(new Kasus("K-"+(seqK++),"Penggelapan Dana","Proses","110"));
        kasus.add(new Kasus("K-"+(seqK++),"Pelanggaran Ormas","Ditutup","112"));
    }
}
